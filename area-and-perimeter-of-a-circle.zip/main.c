/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float radius,area,perimeter;
    float pi=3.14;
    printf("enter the radius of the circle :");
    scanf("%f",&radius);
    
   area=pi*radius*radius;
    
    printf("area of the circle is %f\n " ,area);
    
    
    perimeter=2*pi*radius;
    printf("perimeter of the circle is %f " ,perimeter);
    

    return 0;
}
