/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,i,j,temp;
    printf("enter the no of elements:");
    scanf("%d",&n);
    int arr[n];
    
    //scanning th unsorted array
    for(i=0;i<n;i++){
        scanf("%d ",&arr[i]);
    }
    
    //selection sort
    for(i=0;i<n;i++){
        for(j=i+1;j<n;j++){
            if(arr[i]>arr[j]){
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }
        }        
    }
         
    //printing sorted array 
    for(i=0;i<n;i++){
        printf("%d ",arr[i]);
    }

    return 0;
}
