
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int n,sum=0,rm;
   printf("enter the digit :");
   scanf("%d",&n);
   
   while(n!=0){
       rm=n%10;
       sum=rm+sum;
       n=n/10;
   }
   printf("sum=%d",sum);
   
    return 0;
}
