/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[]={12,21,33,49,54};
    int left=0;
    int num,middle;
    printf("enter the element to search :");
    scanf("%d",&num);
    int right=sizeof(arr)/sizeof(arr[0])-1;
    
    while(left<=right){
        middle=(right+left)/2;
            if(arr[middle]==num){
                printf("the element in %d index",middle);
                break;
            }
            else if(arr[middle]>num){
                right=middle -1;
            }
            else
            left=middle+1;
        }
        if(left>right){
            printf("the element not found in the list");
        }

    return 0;
}
